"""Smart Parking KRR package."""
